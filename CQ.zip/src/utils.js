export default function say() {
    console.log('hello world ');
}